package com;

public class BookDetails {
private String AuthorName;
private String bookTitle;
private int pages;
public String getAuthorName() {
	return AuthorName;
}
public void setAuthorName(String authorName) {
	AuthorName = authorName;
}
public String getBookTitle() {
	return bookTitle;
}
public void setBookTitle(String bookTitle) {
	this.bookTitle = bookTitle;
}
public int getPages() {
	return pages;
}
public void setPages(int pages) {
	this.pages = pages;
}
public BookDetails(String authorName, String bookTitle, int pages) {
	super();
	AuthorName = authorName;
	this.bookTitle = bookTitle;
	this.pages = pages;
}

}
