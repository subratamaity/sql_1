package com;

public class Test {
int id;
String Title;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getTitle() {
	return Title;
}
public void setTitle(String title) {
	Title = title;
}
public Test(int id, String title) {
	super();
	this.id = id;
	Title = title;
}
public Test()
{
	
}
}
