package com;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class TestProcedure {

	static Connection con = null;
	static Statement st = null;
	static ResultSet rs = null;
	static String querry = "SELECT * FROM TBL_TEST_1190311";
	public static void main(String[] args) {
		DbTransaction Dbt1 = new DbTransaction("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","TBL_TEST_1190311","aja10core","aja10core");
		System.out.println(getTestCount(Dbt1));
		ArrayList<Test> tl = (getTest(Dbt1,1234));
		for(Test t:tl)
			System.out.println(t.Title);
		

	}
public static int getTestCount(DbTransaction dbt)
{
	
	int count =0;
	//Test t = new Test();
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
	con= DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","aja10core","aja10core");
	st = con.createStatement();
	rs = st.executeQuery(querry);
	while(rs.next())
	{
		
	 //t.id=rs.getInt(1);
	 //t.Title = rs.getString(2);
	 //System.out.println(t.id);
	 //System.out.println(","+t.Title);
	 count++;
	}
	return count;
	}catch(SQLException se){
	      //Handle errors for JDBC
	      se.printStackTrace();
} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return count;
}
public static ArrayList<Test> getTest(DbTransaction dbt,int id)

{
	ArrayList<Test>testlist = new ArrayList<Test>();
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
	con= DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP","aja10core","aja10core");
	st = con.createStatement();
	rs = st.executeQuery("SELECT * FROM TBL_TEST_1190311 WHERE TEST_ID > "+id);
	Test t = null;
	while(rs.next())
	{
		t=new Test(rs.getInt(1), rs.getString(2));
		testlist.add(t);
	}
	return testlist;
}catch(SQLException se){
    //Handle errors for JDBC
    se.printStackTrace();
}catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	return testlist;
}
}