package com;

public class StudentDepartment {

	private String studentName;
	private String studentContact;
	private String deptName;
	private String deptOwner;
	public StudentDepartment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentDepartment(String studentName, String studentContact,
			String deptName, String deptOwner) {
		super();
		this.studentName = studentName;
		this.studentContact = studentContact;
		this.deptName = deptName;
		this.deptOwner = deptOwner;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentContact() {
		return studentContact;
	}
	public void setStudentContact(String studentContact) {
		this.studentContact = studentContact;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptOwner() {
		return deptOwner;
	}
	public void setDeptOwner(String deptOwner) {
		this.deptOwner = deptOwner;
	}
	
}
