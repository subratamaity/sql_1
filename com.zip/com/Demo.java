package com;

import java.sql.SQLException;
import java.sql.Statement;

public class Demo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DbTransaction d=new DbTransaction("aja10core", "TBL_DEPARTMENT_"+args[0],"TBL_Student_"+args[0],"url","password");
		Create(d);
		Department d1=new Department(1, "cse", "praveen");
		Department d2=new Department(2, "it", "praveen1");
		Department d3=new Department(3, "ece", "praveen2");
		Student s1 =new Student(1, 1, "praveen", "villupuram", "vit");
		Student s2 =new Student(2, 1, "praveen1", "villupuram1", "vit1");
		Student s3 =new Student(3, 2, "praveen2", "villupuram2", "vit2");
		Student s4 =new Student(4, 1, "praveen3", "villupura3", "vit3");
		Student s5 =new Student(5, 3, "praveen4", "villupuram4", "vit4");
		System.out.println(TestProcedure.addDepartment(d, d1));
		System.out.println(TestProcedure.addDepartment(d, d2));
		TestProcedure.addDepartment(d, d3);
		TestProcedure.addStudent(d, s1);
		TestProcedure.addStudent(d, s2);
		TestProcedure.addStudent(d, s3);
		TestProcedure.addStudent(d, s4);
		System.out.println(TestProcedure.addStudent(d, s5));
		TestProcedure.displayStudentAndDepartment(d, 1);
		TestProcedure.displayStudentAndDepartment(d, 2);
		TestProcedure.displayStudentAndDepartment(d, 3);
		TestProcedure.displayStudentAndDepartment(d, 4);
		TestProcedure.displayCountofStudentByDepartment(d);
		try {
			Statement ss1=d.getConnection().createStatement();
			ss1.execute("drop table "+d.getTableName1());
			ss1.execute("drop table "+d.getTableName());
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		


	}
	
	public static void Create(DbTransaction d)
	{
		try {
			Statement smt=d.getConnection().createStatement();
			smt.execute("CREATE TABLE "+d.getTableName()+"(dept_id NUMBER(4) PRIMARY KEY ,dept_name VARCHAR2(30) UNIQUE , dept_owner VARCHAR2(30) UNIQUE)");
			System.out.println("created");
			smt.execute("CREATE TABLE TBL_student_1190361 (student_id NUMBER(4) PRIMARY KEY ,dept_id NUMBER(4) ,student_name VARCHAR2(10),student_address VARCHAR2(20),student_contact VARCHAR2(10),FOREIGN KEY (dept_Id) REFERENCES tbl_department_1190361 (dept_id))");
			System.out.println("created");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
}
