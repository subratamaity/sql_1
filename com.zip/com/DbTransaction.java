package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbTransaction {
	Connection connection;
	private String password;
	private String tableName;
	private String tableName1;
	private String url;
	private String user;
	public DbTransaction(String password, String tableName, String tableName1,
			 String url, String user) {
		super();
		this.password = password;
		this.tableName = tableName;
		this.tableName1 = tableName1;
		this.url = url;
		this.user = user;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getTableName1() {
		return tableName1;
	}
	public void setTableName1(String tableName1) {
		this.tableName1 = tableName1;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Connection getConnection() {
		try
		{
			closeConnection();
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection=DriverManager.getConnection(url, user, password);
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		
		return connection;
	}
	public void closeConnection()
	{
		try
		{
			if(connection!=null && connection.isClosed()==false)
				connection.close();
			connection=null;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}

}
