package com;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TestProcedure {
	
	public static int addDepartment(DbTransaction d,Department d1)
	{
		int i=0;
		try {
			
			String sql="INSERT INTO "+d.getTableName()+" values(?,?,?)";
			PreparedStatement smt=d.getConnection().prepareStatement(sql);
			smt.setInt(1, d1.getDeptId());
			smt.setString(2, d1.getDeptName());
			smt.setString(3, d1.getDeptOwner());
			i=smt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		if(i<=0)
			i=-1;
			else i=1;
			
			return i;
		
	}
	
	public static int addStudent(DbTransaction d,Student s1)
	{
		int i=0;
		try {
			
			String sql="INSERT INTO tbl_student_1190361 values(?,?,?,?,?)";
			PreparedStatement smt=d.getConnection().prepareStatement(sql);
			smt.setInt(1, s1.getStudentId());
			smt.setInt(2, s1.getDeptId());
			smt.setString(3, s1.getStudentName());
			smt.setString(4, s1.getStudentAddress());
			smt.setString(5, s1.getStudentContact());
			i=smt.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		if(i<=0)
		i=-1;
		else i=1;
		
		return i;
	}
	
	public static List<StudentDepartment> displayStudentAndDepartment(DbTransaction d,int i)
	{
		List<StudentDepartment> w=new ArrayList<StudentDepartment>();
		try {
			Statement smt=d.getConnection().createStatement();
			ResultSet rs=smt.executeQuery("SELECT TBL_Student_1190361.student_name ,TBl_Student_1190361.student_contact ,TBL_Department_1190361.dept_name ,TBL_Department_1190361.dept_owner from TBL_Student_1190361 , TBL_Department_1190361 where TBL_Department_1190361.dept_id = TBL_Student_1190361.dept_id and TBL_Student_1190361.student_id="+i );
			while(rs.next())
			{
				StudentDepartment s = new StudentDepartment();
				s.setStudentName(rs.getString(1));
				s.setStudentContact(rs.getString(2));
				s.setDeptName(rs.getString(3));
				s.setDeptOwner(rs.getString(4));
				w.add(s);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return w;
	}
	public static void displayCountofStudentByDepartment(DbTransaction d)
	{
		try {
			Statement smt=d.getConnection().createStatement();
			ResultSet rs=smt.executeQuery("SELECT TBL_DEPARTMENT_1190361.DEPT_NAME , COUNT(TBL_STUDENT_1190361.student_ID) FROM TBL_DEPARTMENT_1190361 LEFT JOIN TBL_STUDENT_1190361 ON TBL_DEPARTMENT_1190361.DEPT_ID = TBL_STUDENT_1190361.DEPT_ID GROUP BY (TBL_DEPARTMENT_1190361.DEPT_NAME)");
			while(rs.next())
			{
				System.out.println(rs.getString(1)+"   :"+rs.getInt(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
