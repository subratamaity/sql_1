package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DbTransaction {
String url;
String TableName;
String tableName1;
String tableName2;

Connection connection;
String User;
String Password;
public String getUrl() {
	return url;
}
public void setUrl(String url) {
	this.url = url;
}
public String getTableName() {
	return TableName;
}
public void setTableName(String tableName) {
	TableName = tableName;
}

public String getTableName1() {
	return tableName1;
}
public void setTableName1(String tableName1) {
	this.tableName1 = tableName1;
}
public String getTableName2() {
	return tableName2;
}
public void setTableName2(String tableName2) {
	this.tableName2 = tableName2;
}
public DbTransaction(String url, String tableName, String user, String password) {
	super();
	this.url = url;
	TableName = tableName;
	User = user;
	Password = password;
}
public Connection getConnection()
{
try {
closeConnection();
Class.forName("oracle.jdbc.driver.OracleDriver");
connection = DriverManager.getConnection(url,User,Password);
} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
} catch (ClassNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
return connection;
}
public void closeConnection()
{
try
{
if(connection != null && connection.isClosed() == false)
connection.close();
connection = null;
}
catch(SQLException e)
{
e.printStackTrace();
}
}

}
