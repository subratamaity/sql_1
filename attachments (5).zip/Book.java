package com;

public class Book {
int Book_id;
String Title;
double Price;
int Pages;
public int getBook_id() {
	return Book_id;
}
public void setBook_id(int book_id) {
	Book_id = book_id;
}
public String getTitle() {
	return Title;
}
public void setTitle(String title) {
	Title = title;
}
public double getPrice() {
	return Price;
}
public void setPrice(double price) {
	Price = price;
}
public int getPages() {
	return Pages;
}
public void setPages(int pages) {
	Pages = pages;
}
public Book(int book_id, String title, double price, int pages) {
	super();
	Book_id = book_id;
	Title = title;
	Price = price;
	Pages = pages;
}

}
